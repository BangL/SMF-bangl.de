<?php
/**
 * @package Facebook Slide Like Box
 * @author phantom
 * @copyright 2012
 * @license http://creativecommons.org/licenses/by-nc-nd/3.0/ CC BY-NC-ND 3.0
 * @version 2.1.3
**/

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')) 
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

$hooks = array(
	'integrate_pre_include' => '$sourcedir/Subs-FBSlideLikeBox.php',
	'integrate_load_theme' => 'FBSlideLikeBox_load_theme',
	'integrate_admin_areas' => 'FBSlideLikeBox_admin_areas',
	'integrate_modify_modifications' => 'FBSlideLikeBox_modify_modifications',
	'integrate_load_permissions' => 'FBSlideLikeBox_permissions',
	/*'integrate_menu_buttons' => 'FBSlideLikeBox_menu_buttons'*/
);

if (!empty($context['uninstalling']))
	$call = 'remove_integration_function';
else
	$call = 'add_integration_function';

foreach ($hooks as $hook => $function)
	$call($hook, $function);

?>