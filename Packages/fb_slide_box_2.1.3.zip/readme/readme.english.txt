This modification display your entries from Facebook in sliding panel

[code]
Changelog:
30.01.2013 - 2.1.2 for SMF 2.0.*
 - fixed few typos
 
30.01.2013 - 2.1.1 for SMF 2.0.*
 - merged iframe and HTML5 code
 - removed requirement for App ID, now it's optional
 - added permission settings on mod settings page
 - other small changes

26.08.2012  - 2.1 for SMF 2.0.*
 - MOD REQUIRES FACEBOOK APP ID
 - old iframe code was replaced by HTML5 code
 - added ability to disable jQuery animations
 - added option to change speed of animation
 - added option to change how slide box will be launched (after click or after hover)
 - compatibility with MooTools
 - from now you can allow users to disable slide box (Profile > Look and Layout) 
 - other minor changes..

3.05.2012  - 2.0.3
 - fixed 'Undefined variable' error
 - in getimagesize() changed image URL to image path
 - updated German translation (thx Eclipse16V)
 - added Hungarian translation (thx novill)

28.04.2012  - 2.0.2
 - changes in function hiding box for mobile users (now it will work if you have not installed Mobile Device Detect)
 - few changes in function hiding mod in selected actions
 - added permissions for groups
 - few other fixes..

1.04.2012  - 2.0.1
 - small fixes..

24.03.2012  - 2.0
 - mod rewritten to use hooks
 - setting to disable mod for mobile users
 - setting to disable mod in selected actions
[/code]