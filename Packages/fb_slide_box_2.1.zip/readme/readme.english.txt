This modification display your entries from Facebook in sliding panel

Changelog:
 - old iframe code was replaced by HTML5 code
 - added ability to disable jQuery animations
 - added option to change speed of animation
 - added option to change how slide box will be launched (after click or after hover)
 - compatibility with MooTools
 - from now you can allow users to disable slide box (Profile > Look and Layout) :)
 - other minor changes..
