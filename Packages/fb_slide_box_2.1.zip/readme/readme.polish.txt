Z t� modyfikacj� dodasz na swoim forum wysuwany widget z wpisami ze swojego profilu w serwisie Facebook

Lista zmian w stosunku do wersji 2.0.3:
 - Kod iframe zosta� zamieniony na HTML5
 - dodana mo�liwo�� wy��czenia animacji jQuery
 - dodana opcja zmiany pr�dko�ci animacji
 - opcja zmiany sposobu w��czania slide boxa
 - poprawiona kompatybilno�� z modami korzystaj�cymi z wtyczki MooTools
 - od teraz mo�esz zezwoli� u�ytkownikom na wy��czenie slide boxa (Profil > Opcje wygl�du) :)
 - drobne poprawki w kodzie
