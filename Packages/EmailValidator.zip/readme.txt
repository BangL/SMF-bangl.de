[b]E-mail Validator[/b]

This modification adds a validate e-mail feature on registration to prevent people registering on your forums with a fake e-mail adress.

You can turn it on/off from:

Admin Control Panel >> Registration >> Settings

[b]-[SiNaN][/b]
